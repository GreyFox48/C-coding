var searchData=
[
  ['value',['value',['../structcolor__t.html#ae346ea49d8896a5233739803fdc1671c',1,'color_t']]]
];
