var searchData=
[
  ['sdl_5frender_5flife',['sdl_render_life',['../sdl_8h.html#afec672c5d4f9b0381339bd3229f28889',1,'sdl.h']]],
  ['sdl_5ftest',['sdl_test',['../sdl_8h.html#ada6b3150b36edb0a418e47d340006ea4',1,'sdl.h']]]
];
