var searchData=
[
  ['init_5fsdl_5finfo',['init_sdl_info',['../sdl_8h.html#a1094292af49bb6c4abf089ab73a79bb9',1,'sdl.h']]]
];
