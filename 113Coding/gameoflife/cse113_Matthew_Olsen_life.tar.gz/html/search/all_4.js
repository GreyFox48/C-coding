var searchData=
[
  ['gl_2ec',['gl.c',['../gl_8c.html',1,'']]],
  ['green',['green',['../structcolor__t.html#a85e1636e41c5772cf432e4612ed00310',1,'color_t']]]
];
