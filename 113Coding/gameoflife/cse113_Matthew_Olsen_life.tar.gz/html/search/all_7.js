var searchData=
[
  ['klein',['klein',['../life_8c.html#a0d7d5399197b391bbd3e87ab785da544',1,'klein(struct frame_t *new, struct frame_t *old):&#160;life.c'],['../life_8h.html#a0d7d5399197b391bbd3e87ab785da544',1,'klein(struct frame_t *new, struct frame_t *old):&#160;life.c']]],
  ['klein_5fcell',['klein_cell',['../life_8c.html#a58bbc40d4cba7e9e668245e6714b39bb',1,'klein_cell(struct frame_t *old, int x, int y):&#160;life.c'],['../life_8h.html#a58bbc40d4cba7e9e668245e6714b39bb',1,'klein_cell(struct frame_t *old, int x, int y):&#160;life.c']]]
];
