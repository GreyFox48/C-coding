var searchData=
[
  ['sdl_5finfo_5ft',['sdl_info_t',['../structsdl__info__t.html',1,'']]]
];
