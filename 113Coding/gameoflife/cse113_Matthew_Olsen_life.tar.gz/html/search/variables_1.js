var searchData=
[
  ['color',['color',['../structsdl__info__t.html#a793e548fc0386a76cdee71647bd096d4',1,'sdl_info_t']]],
  ['cols',['cols',['../structframe__t.html#a96919b0b361540c57b7b5cca5c492b8d',1,'frame_t']]]
];
