var searchData=
[
  ['file_5ffailure',['FILE_FAILURE',['../life_8c.html#a17e5178c456be07bd6654ae2dacee9b3',1,'life.c']]],
  ['frame_5ft',['frame_t',['../structframe__t.html',1,'']]],
  ['free_5fframe',['free_frame',['../life_8c.html#a4d5950ffb84a5a6f6dd087921f8485b2',1,'free_frame(struct frame_t *frame):&#160;life.c'],['../life_8h.html#a4d5950ffb84a5a6f6dd087921f8485b2',1,'free_frame(struct frame_t *frame):&#160;life.c']]]
];
