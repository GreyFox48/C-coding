var searchData=
[
  ['main',['main',['../gl_8c.html#a0ddf1224851353fc92bfbff6f499fa97',1,'gl.c']]],
  ['modulus',['modulus',['../life_8c.html#a654e3ae2d6c4d5a50bc82fcf71b83861',1,'modulus(int numerator, int denominator):&#160;life.c'],['../life_8h.html#a654e3ae2d6c4d5a50bc82fcf71b83861',1,'modulus(int numerator, int denominator):&#160;life.c']]]
];
