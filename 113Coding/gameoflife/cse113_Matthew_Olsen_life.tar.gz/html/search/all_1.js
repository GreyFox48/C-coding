var searchData=
[
  ['color',['color',['../structsdl__info__t.html#a793e548fc0386a76cdee71647bd096d4',1,'sdl_info_t']]],
  ['color_5ft',['color_t',['../structcolor__t.html',1,'']]],
  ['cols',['cols',['../structframe__t.html#a96919b0b361540c57b7b5cca5c492b8d',1,'frame_t']]],
  ['create_5fframe',['create_frame',['../life_8c.html#a3e8b96b41a46808a1e2599feb4b71d20',1,'create_frame(int width, int height, int sprite_size):&#160;life.c'],['../life_8h.html#a3e8b96b41a46808a1e2599feb4b71d20',1,'create_frame(int width, int height, int sprite_size):&#160;life.c']]],
  ['create_5flife',['create_life',['../life_8c.html#a485b114fcaef036c475040c2f6716491',1,'create_life(struct frame_t *frame, char *file, int x, int y, int edge):&#160;life.c'],['../life_8h.html#a485b114fcaef036c475040c2f6716491',1,'create_life(struct frame_t *frame, char *file, int x, int y, int edge):&#160;life.c']]],
  ['create_5flife_5f105',['create_life_105',['../life_8c.html#a94cc909c73cc4678b2c21a8c155f9a1d',1,'create_life_105(struct frame_t *frame, FILE *fp, int x, int y, int edge):&#160;life.c'],['../life_8h.html#a94cc909c73cc4678b2c21a8c155f9a1d',1,'create_life_105(struct frame_t *frame, FILE *fp, int x, int y, int edge):&#160;life.c']]],
  ['create_5flife_5f106',['create_life_106',['../life_8c.html#aa3bb9a362e3df245a5a7b9cbfdb4ea12',1,'create_life_106(struct frame_t *frame, FILE *fp, int x, int y, int edge):&#160;life.c'],['../life_8h.html#aa3bb9a362e3df245a5a7b9cbfdb4ea12',1,'create_life_106(struct frame_t *frame, FILE *fp, int x, int y, int edge):&#160;life.c']]],
  ['create_5fmatrix',['create_matrix',['../life_8c.html#a75693e059a2a9ecb057e214aaa0525e3',1,'create_matrix(struct frame_t *frame):&#160;life.c'],['../life_8h.html#a75693e059a2a9ecb057e214aaa0525e3',1,'create_matrix(struct frame_t *frame):&#160;life.c']]]
];
