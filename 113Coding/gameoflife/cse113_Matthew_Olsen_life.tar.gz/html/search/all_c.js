var searchData=
[
  ['texture',['texture',['../structsdl__info__t.html#a0c62b9f6687072b1e255ad27dc3db919',1,'sdl_info_t']]],
  ['todo_20list',['Todo List',['../todo.html',1,'']]],
  ['torus',['torus',['../life_8c.html#a75bd84b0de0eb4328b80f475077a450b',1,'torus(struct frame_t *new, struct frame_t *old):&#160;life.c'],['../life_8h.html#a75bd84b0de0eb4328b80f475077a450b',1,'torus(struct frame_t *new, struct frame_t *old):&#160;life.c']]],
  ['torus_5fcell',['torus_cell',['../life_8c.html#a326d0d2996bd46370dc64bcf25848a8d',1,'torus_cell(struct frame_t *old, int x, int y):&#160;life.c'],['../life_8h.html#a326d0d2996bd46370dc64bcf25848a8d',1,'torus_cell(struct frame_t *old, int x, int y):&#160;life.c']]]
];
