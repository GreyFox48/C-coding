var searchData=
[
  ['free_5fframe',['free_frame',['../life_8c.html#a4d5950ffb84a5a6f6dd087921f8485b2',1,'free_frame(struct frame_t *frame):&#160;life.c'],['../life_8h.html#a4d5950ffb84a5a6f6dd087921f8485b2',1,'free_frame(struct frame_t *frame):&#160;life.c']]]
];
