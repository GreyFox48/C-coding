var searchData=
[
  ['hedge',['hedge',['../life_8c.html#ab571a1cdb4b2e5a38bfb55edee4580b7',1,'hedge(struct frame_t *new, struct frame_t *old):&#160;life.c'],['../life_8h.html#ab571a1cdb4b2e5a38bfb55edee4580b7',1,'hedge(struct frame_t *new, struct frame_t *old):&#160;life.c']]],
  ['hedge_5fcell',['hedge_cell',['../life_8c.html#a7afcf0b66d6b32bef40050849b056959',1,'hedge_cell(struct frame_t *old, int x, int y):&#160;life.c'],['../life_8h.html#a7afcf0b66d6b32bef40050849b056959',1,'hedge_cell(struct frame_t *old, int x, int y):&#160;life.c']]],
  ['height',['height',['../structsdl__info__t.html#ae23e8fb74d99bcd74a3f121aafdf2831',1,'sdl_info_t']]]
];
