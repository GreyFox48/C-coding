#include "processor.h"

MESSAGE messageCache[CACHE_SIZE];

void addMessageToCache(char *inputLine)
{
    // TODO See the description of the Task 10
}

void messageDispatcher(void)
{
    // TODO See the description of the Task 10
}

void processMessage(MESSAGE *message)
{
    // TODO See the description of the Task 10
}

void printStatistics(void)
{
    // TODO See the description of the Task 10
}
