#ifndef RANDOM_H_
#define RANDOM_H_

int nrand(int range);
void seed();

#endif
