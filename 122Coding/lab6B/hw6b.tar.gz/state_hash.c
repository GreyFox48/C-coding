#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#define LEN 4096

struct postal_t {
        char *abrv; /*two digit abbreviation, capitalized */
        char *name; /*name in start case */
};


/*  convert string to lowercase */
void tolowercase(char *s)
{
        //todo
}

/* trim off whitespace from the right */
void rstrip(char *s)
{
        //todo
}

int main(int argc, char *argv[])
{
        char buf[LEN];
        struct postal_t *postal = malloc(200 * sizeof(struct postal_t));

	FILE *fp = fopen("postal", "r");
	assert(fp);

	while(fgets(buf, LEN, fp)) {
	        printf("%s\n", buf);
        }

        fclose(fp);
        return 0;
}

