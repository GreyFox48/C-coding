/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_434(unsigned x)
{
    return x + 3284634440U;
}

unsigned addval_226(unsigned x)
{
    return x + 3281031256U;
}

unsigned getval_180()
{
    return 2428995912U;
}

void setval_400(unsigned *p)
{
    *p = 2462550344U;
}

unsigned addval_174(unsigned x)
{
    return x + 4284793816U;
}

unsigned getval_446()
{
    return 2425393272U;
}

void setval_131(unsigned *p)
{
    *p = 2421731299U;
}

unsigned getval_317()
{
    return 2428995912U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_497()
{
    return 3286270280U;
}

unsigned addval_473(unsigned x)
{
    return x + 3374371225U;
}

unsigned getval_496()
{
    return 3286272328U;
}

unsigned addval_223(unsigned x)
{
    return x + 3281044105U;
}

void setval_185(unsigned *p)
{
    *p = 3221799625U;
}

unsigned getval_341()
{
    return 2464188744U;
}

void setval_440(unsigned *p)
{
    *p = 3229929097U;
}

void setval_311(unsigned *p)
{
    *p = 3523793281U;
}

void setval_305(unsigned *p)
{
    *p = 3229929865U;
}

void setval_364(unsigned *p)
{
    *p = 3767093433U;
}

unsigned addval_182(unsigned x)
{
    return x + 3281309321U;
}

unsigned addval_145(unsigned x)
{
    return x + 3348156041U;
}

unsigned getval_130()
{
    return 1740882633U;
}

void setval_439(unsigned *p)
{
    *p = 3286272264U;
}

unsigned getval_286()
{
    return 3682910889U;
}

unsigned addval_227(unsigned x)
{
    return x + 3674263945U;
}

unsigned getval_443()
{
    return 3687109001U;
}

unsigned getval_343()
{
    return 3264266889U;
}

unsigned getval_428()
{
    return 3380138377U;
}

unsigned addval_113(unsigned x)
{
    return x + 3284304341U;
}

unsigned getval_158()
{
    return 2464188744U;
}

unsigned addval_411(unsigned x)
{
    return x + 3767355593U;
}

void setval_314(unsigned *p)
{
    *p = 3531915913U;
}

unsigned addval_382(unsigned x)
{
    return x + 3378564745U;
}

void setval_257(unsigned *p)
{
    *p = 3677933193U;
}

unsigned addval_193(unsigned x)
{
    return x + 3526939017U;
}

void setval_487(unsigned *p)
{
    *p = 3281047169U;
}

void setval_463(unsigned *p)
{
    *p = 3523793353U;
}

void setval_210(unsigned *p)
{
    *p = 2495777234U;
}

unsigned getval_105()
{
    return 3269495112U;
}

void setval_337(unsigned *p)
{
    *p = 3234123401U;
}

void setval_132(unsigned *p)
{
    *p = 3531919017U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
